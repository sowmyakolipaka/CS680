package edu.cs.cs680;
import java.awt.Point;
import java.util.ArrayList;

public class RectangleAreaCalc implements AreaCalculator {

	@Override
	public float getArea(ArrayList<Point> points) {
		// TODO Auto-generated method stub
		double l=points.get(0).distance(points.get(1));
		double b=points.get(1).distance(points.get(2));
		double area=l*b;
		return (float) area;
	}
}
