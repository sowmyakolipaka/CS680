package edu.cs.cs680;
import java.awt.Point;
import java.util.ArrayList;

public interface AreaCalculator {
	
	float getArea(ArrayList<Point> points);
	}
