package edu.cs.cs680;
import java.awt.Point;
import java.util.ArrayList;

public class Polygon {

	ArrayList< Point> points;
	AreaCalculator areaCalc;
	CentroidCalculator centroidCalc;

	public Polygon(ArrayList<Point> points, AreaCalculator areaCalc) {
		super();
		this.points = points;
		this.areaCalc = areaCalc;
	}
	
	public Polygon(ArrayList<Point> points, CentroidCalculator centroidCalc) {
		super();
		this.points = points;
		this.centroidCalc = centroidCalc;
	}
	

	public void setAreaCalc(AreaCalculator calc) {	
		this.areaCalc=calc;
	}
	
	public void setCentroidCalc(CentroidCalculator centroidCalc) {
		this.centroidCalc = centroidCalc;
	}
	
	void addPoint(Point p) {
		points.add(p);
	}

	float getArea() {
		return areaCalc.getArea(points);
	}
	
	Point getCentroid() {
		return centroidCalc.getControid(points);
	}
	
	void removePoint() {
		points.remove(points.size()-1);
	}
}
