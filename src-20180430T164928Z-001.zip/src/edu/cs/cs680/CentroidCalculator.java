package edu.cs.cs680;
import java.awt.Point;
import java.util.ArrayList;

public interface CentroidCalculator {
	Point getControid(ArrayList<Point> points);
}
