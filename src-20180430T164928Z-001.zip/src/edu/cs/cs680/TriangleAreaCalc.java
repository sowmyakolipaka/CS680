package edu.cs.cs680;
import java.awt.Point;
import java.util.ArrayList;

public class TriangleAreaCalc  implements AreaCalculator{

	@Override
	public float getArea(ArrayList<Point> points) {
		// TODO Auto-generated method stub
		double a= points.get(0).distance(points.get(1));
		double b=points.get(1).distance(points.get(2));
		double c=points.get(2).distance(points.get(0));
		double s=(a+b+c)/2;
		double area=Math.sqrt(s*(s-a)*(s-b)*(s-c));
		
		return (float) area;
	}

}
