package edu.cs.cs680;
import java.awt.Point;
import java.util.ArrayList;

public class TriangleCentroid implements CentroidCalculator {

	
	@Override
	public Point getControid(ArrayList<Point> points) {
		// TODO Auto-generated method stub
		
		double x=(points.get(0).getX()+ points.get(1).getX()+ points.get(2).getX())/3;
		double y=(points.get(0).getY()+points.get(1).getY()+points.get(2).getY())/3;

		Point p = new Point() ;
		p.setLocation(x, y);
		return p;
	}
}