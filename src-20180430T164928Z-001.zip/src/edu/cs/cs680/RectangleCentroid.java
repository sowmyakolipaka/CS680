package edu.cs.cs680;
import java.awt.Point;
import java.util.ArrayList;

public class RectangleCentroid implements CentroidCalculator {

	
	@Override
	public Point getControid(ArrayList<Point> points) {
		// TODO Auto-generated method stub
		double x=points.get(0).distance(points.get(1));
		double y=points.get(1).distance(points.get(2));
		
		Point p = new Point();
		p.setLocation(x/2, y/2);
		return p;
	}

}
