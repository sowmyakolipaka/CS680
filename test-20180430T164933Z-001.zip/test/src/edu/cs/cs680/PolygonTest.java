package edu.cs.cs680;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.awt.Point;
import java.util.ArrayList;

import org.junit.Test;

public class PolygonTest {

	@Test
	public void testGetArea() {
		ArrayList<Point> al = new ArrayList<Point>();
		al.add(new Point(0, 3));
		al.add(new Point(0, 0));
		al.add(new Point(3, 0));

		Polygon PolyArea = new Polygon(al, new TriangleAreaCalc());

		float expected = 4.5f;
		float actual = PolyArea.getArea();
		assertThat(actual, is(expected));

		PolyArea.addPoint(new Point(3, 3));
		PolyArea.setAreaCalc(new RectangleAreaCalc());
		expected = 9.0f;
		actual = PolyArea.getArea();

		assertThat(actual, is(expected));

		PolyArea.removePoint();
		PolyArea.setAreaCalc(new TriangleAreaCalc());
		expected = 4.5f;
		actual = PolyArea.getArea();
		
		assertThat(actual, is(expected));

	}
	
	@Test
	public void testGetCentroid() {

		ArrayList<Point> al = new ArrayList<Point>();
		al.add(new Point(0, 3));
		al.add(new Point(0, 0));
		al.add(new Point(3, 0));
		Polygon PolyCentroid = new Polygon(al, new TriangleCentroid());

		Point actual = PolyCentroid.getCentroid();
		Point expected = new Point(1, 1);
		assertThat(actual, is(expected));

		PolyCentroid.addPoint(new Point(3, 3));
		PolyCentroid.setCentroidCalc(new RectangleCentroid());

		actual = PolyCentroid.getCentroid(); // rectangle�s area
		expected = new Point(2, 2);

		assertThat(actual, is(expected));

		PolyCentroid.removePoint();
		PolyCentroid.setCentroidCalc(new TriangleCentroid());;
		actual = PolyCentroid.getCentroid();
		expected = new Point(1, 1);
		assertThat(actual, is(expected));

	}

}
